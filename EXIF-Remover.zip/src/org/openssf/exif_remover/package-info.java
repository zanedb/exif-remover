/**
 * 
 */
/**
 * @author Open Software Services Foundation (@openssf on GitHub)
 * @license GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)
 * @version 1.0
 */
package org.openssf.exif_remover;